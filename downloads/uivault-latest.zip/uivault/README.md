# UI Vault 3.0.0

Modular, framework-free UI kit. Mix themes, components and effects per element.

## Quick start
1. Copy `uivault.css` and `uivault.js` into your project (or pick modules from `css/` and `js/`).
2. Add them to your page:
   <link rel="stylesheet" href="uivault.css">
   <script src="uivault.js" defer></script>
3. Use classes and attributes:
   <button class="uv-btn uv-btn--primary" data-uv="ripple">Hello</button>
   <section data-uv-theme="neon">Any element can have its own theme.</section>
   <h1 class="uv-fx-glitch">Effects are stackable classes.</h1>

Open `examples/index.html` for a working page.

## Modules
CSS (load core first): core, components, fx, blocks, themes/<name>  (or uivault.css = all)
JS  (load core first): core, motion, feedback, forms, fx            (or uivault.js = all)

Themes: editorial, brutal, neon, glass, terminal, soft, retro, swiss, y2k, mono, sketch, luxe
Docs: https://thenameiscobmarley.github.io/ui-vault/quickstart.html

MIT licensed.
